How To Play:
Left padel is moved with A and Z.
Right padel is moved with K and M.
There is no ending in this game.
If one of the players gets 5 points there will be a new obstacle.
Alt F4 to close the game.