How To Play:
WASD to move. 
Q to go into placement mode.
W and S to move the camera in placement mode.
1, 2 and 3 for the different towers.
E to go back into first person.
G to start the next wave.

