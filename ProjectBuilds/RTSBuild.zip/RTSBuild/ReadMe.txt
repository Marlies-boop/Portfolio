How To Play:
WASD to move the camera.
Shift to move the camera up.
Contol to move the camera down.
Click on the build button to select a building to build.
F to place more workers.
click on one of the red cylinders (workers) to see if they are doing anything.
When you have selected a worker you can right click to move them somewhere or click on a resource (stone or wood) to make them work.
This game doesn't have an ending.
Alt F4 to close the game.