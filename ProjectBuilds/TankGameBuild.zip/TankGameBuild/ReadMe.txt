How To Play:
A and D or left and right arrows to move sideways.
W and S or up and down arrows to aim.
Q to add power and E to decrease power.
There is no end to this game.
Alt F4 to close the game.
