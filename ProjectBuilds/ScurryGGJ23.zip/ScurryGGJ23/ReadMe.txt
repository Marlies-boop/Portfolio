How To Play:
WASD to move.
Shift to run.
E to interact.
Interact with the bird to receive acorns.
Go to the workbench to set up your defences.
You can place 3 different defences. A wall, turrets or a mine.
Your acorns are also your ammo.
If you don't have any acorns you can't attack.
After each wave you'll have the ability to receive more acorns. 
You can give some acorns to the bird to double them next round.
There are 3 rounds, after the 3rd round you have to wait for the timer to end before you get the end screen.
