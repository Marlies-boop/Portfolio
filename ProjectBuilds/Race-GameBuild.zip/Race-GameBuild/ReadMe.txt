How To Play:
WASD to move.
If you don't drive over the path the game will teleport you back to a previous checkpoint.
